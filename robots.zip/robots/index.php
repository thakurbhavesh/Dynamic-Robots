<?php
// File path to robots.txt
$robots_file = 'robots.txt';

// Function to read robots.txt file
function readRobotsFile($file_path) {
    if (file_exists($file_path)) {
        return file($file_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    }
    return [];
}

// Function to write to robots.txt file
function writeRobotsFile($file_path, $lines) {
    file_put_contents($file_path, implode("\n", $lines) . "\n");
}

// Initialize variables for form pre-filling
$user_agent = '';
$disallow = '';
$allow = '';
$crawl_delay = '';
$is_editing = false;
$edit_index = null;

// Handle form submission to add or update a rule
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_agent = $_POST['user_agent'];
    $disallow = $_POST['disallow'];
    $allow = $_POST['allow'];
    $crawl_delay = $_POST['crawl_delay'];
    $edit_index = isset($_POST['edit_index']) ? intval($_POST['edit_index']) : null;

    // Read the current rules
    $rules = readRobotsFile($robots_file);

    // If editing, update the rule
    if ($edit_index !== null) {
        $current_rule = -1;
        foreach ($rules as $index => $line) {
            if (strpos($line, 'User-agent:') === 0) {
                $current_rule++;
            }
            if ($current_rule === $edit_index) {
                // Update the rule
                $rules[$index] = "User-agent: $user_agent";
                if (!empty($disallow)) {
                    $rules[$index + 1] = "Disallow: $disallow";
                }
                if (!empty($allow)) {
                    $rules[$index + 2] = "Allow: $allow";
                }
                if (!empty($crawl_delay)) {
                    $rules[$index + 3] = "Crawl-delay: $crawl_delay";
                }
                break;
            }
        }
    } else {
        // Add the new rule
        $rules[] = "User-agent: $user_agent";
        if (!empty($disallow)) {
            $rules[] = "Disallow: $disallow";
        }
        if (!empty($allow)) {
            $rules[] = "Allow: $allow";
        }
        if (!empty($crawl_delay)) {
            $rules[] = "Crawl-delay: $crawl_delay";
        }
        $rules[] = ""; // Add a blank line for separation
    }

    // Write the updated rules back to the file
    writeRobotsFile($robots_file, $rules);
    // Redirect to clear form data after submission
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Handle rule deletion (using line number as identifier)
if (isset($_GET['delete'])) {
    $line_to_delete = intval($_GET['delete']);
    $rules = readRobotsFile($robots_file);
    $new_rules = [];

    // Keep track of the current rule being deleted
    $current_rule = -1;
    foreach ($rules as $line) {
        if (strpos($line, 'User-agent:') === 0) {
            $current_rule++;
        }
        if ($current_rule !== $line_to_delete) {
            $new_rules[] = $line;
        }
    }

    // Write the updated rules back to the file
    writeRobotsFile($robots_file, $new_rules);
    // Redirect to avoid resubmission
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Handle rule editing (pre-fill the form with the selected rule)
if (isset($_GET['edit'])) {
    $line_to_edit = intval($_GET['edit']);
    $rules = readRobotsFile($robots_file);

    // Find the rule to edit
    $current_rule = -1;
    foreach ($rules as $line) {
        if (strpos($line, 'User-agent:') === 0) {
            $current_rule++;
        }
        if ($current_rule === $line_to_edit) {
            // Pre-fill form fields
            if (strpos($line, 'User-agent:') === 0) {
                $user_agent = substr($line, 11);
            }
            if (isset($rules[$line_to_edit + 1]) && strpos($rules[$line_to_edit + 1], 'Disallow:') === 0) {
                $disallow = substr($rules[$line_to_edit + 1], 10);
            }
            if (isset($rules[$line_to_edit + 2]) && strpos($rules[$line_to_edit + 2], 'Allow:') === 0) {
                $allow = substr($rules[$line_to_edit + 2], 7);
            }
            if (isset($rules[$line_to_edit + 3]) && strpos($rules[$line_to_edit + 3], 'Crawl-delay:') === 0) {
                $crawl_delay = substr($rules[$line_to_edit + 3], 13);
            }
            $is_editing = true;
            $edit_index = $line_to_edit;
            break;
        }
    }
}

// Fetch all rules to display
$rules = readRobotsFile($robots_file);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Robots.txt Manager</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body { 
            font-family: 'Roboto', sans-serif; 
            margin: 0; 
            padding: 20px; 
            background-color: #f4f4f9;
        }
       
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        form {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 10px;
            align-items: center;
            margin-bottom: 20px;
        }
        label {
            font-weight: 500;
            color: #555;
        }
        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: #f9f9f9;
        }
        button {
            grid-column: span 2;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #0056b3;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 20px;
            background-color: #fff;
        }
        th, td { 
            padding: 12px; 
            border-bottom: 1px solid #ddd; 
            text-align: left; 
        }
        th { 
            background-color: #f2f2f2; 
            color: #333;
        }
        td { 
            color: #555; 
        }
        a { 
            color: #ff0000; 
            text-decoration: none; 
        }
        a:hover { 
            text-decoration: underline; 
        }
        pre {
            background-color: #eee;
            padding: 15px;
            border-radius: 4px;
            overflow: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h4>Manage robots.txt</h4>
        <form action="" method="POST">
            <label for="user_agent">User Agent:</label>
            <input type="text" name="user_agent" required value="<?= htmlspecialchars($user_agent) ?>">

            <label for="disallow">Disallow:</label>
            <input type="text" name="disallow" value="<?= htmlspecialchars($disallow) ?>">

            <label for="allow">Allow:</label>
            <input type="text" name="allow" value="<?= htmlspecialchars($allow) ?>">

            <label for="crawl_delay">Crawl Delay:</label>
            <input type="number" name="crawl_delay" value="<?= htmlspecialchars($crawl_delay) ?>">

            <?php if ($is_editing): ?>
                <input type="hidden" name="edit_index" value="<?= htmlspecialchars($edit_index) ?>">
                <button type="submit" style='width:40%;margin:10 auto;'>Update Rule</button>
            <?php else: ?>
                <button type="submit" name="add_rule" style='width:40%;margin:10 auto;'>Add Rule</button>
            <?php endif; ?>
        </form>

        <?php
        // Display rules in a table
        if (!empty($rules)) {
            echo "<h2>Existing Rules</h2>";
            echo "<table><tr><th>Rule</th><th>Actions</th></tr>";

            $current_rule = -1;
            foreach ($rules as $index => $line) {
                if (strpos($line, 'User-agent:') === 0) {
                    $current_rule++;
                    if ($current_rule > 0) {
                        echo "</td></tr>";
                    }
                    echo "<tr><td><strong>" . htmlspecialchars($line) . "</strong>";
                } else {
                    echo "<br>" . htmlspecialchars($line);
                }

                if (strpos($line, 'Crawl-delay:') !== false || trim($line) === '') {
                    echo "</td><td>
                            <a href='?edit=" . $current_rule . "' style='color:blue;'>Edit</a> |
                            <a href='?delete=" . $current_rule . "' onclick=\"return confirm('Are you sure?');\">Delete</a>
                          </td></tr>";
                }
            }
            echo "</table>";
        } else {
            echo "<p>No rules defined.</p>";
        }
        ?>

        <h2>Current robots.txt content</h2>
        <pre>
        <?php
        // Display the current content of robots.txt
        echo htmlspecialchars(file_get_contents($robots_file));
        ?>
        </pre>
    </div>
</body>
</html>
